# PS4 3.55 FileBrowser
Read filesystem of PS4 in 3.55

## Credits:
* CTurT
* Fire30
* TheoryWrong
* Anonymous contributor
* And all other people contribute for this project

# MrV1rus Changed Log :
* Test Sockets Now Working
* Encrypted Files

# Upcoming Features:
* Combined Playground with PS 3.55 and PS 1.76
* 
* 

# Sources:
* Orginal Sourced by @TheoryWrong <3
* Moddified By MrV1rus From PSXHAX <3
* 